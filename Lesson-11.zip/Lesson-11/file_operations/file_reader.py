# file_operations/file_reader.py
# Define read_file(file_path) -> returns file contents as a string

def read_file(file_path):
    """Read and return the entire contents of the file at file_path."""
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read()
