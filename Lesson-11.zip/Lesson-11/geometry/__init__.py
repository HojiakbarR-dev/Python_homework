# geometry package initializer
# You can optionally expose specific functions for easier imports:
from .circle import calculate_area, calculate_circumference

__all__ = ["calculate_area", "calculate_circumference"]
