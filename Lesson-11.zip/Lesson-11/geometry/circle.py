
import math
def calculate_area(radius):
    """Calculate area of a circle: pi * r^2"""
    if radius < 0:
        raise ValueError("Radius cannot be negative.")
    return math.pi * (radius ** 2)

def calculate_circumference(radius):
    """Calculate circumference of a circle: 2 * pi * r"""
    if radius < 0:
        raise ValueError("Radius cannot be negative.")
    return 2 * math.pi * radius
