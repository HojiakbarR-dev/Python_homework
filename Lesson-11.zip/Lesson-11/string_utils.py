# string_utils.py
# String utilities: reverse_string and count_vowels
# All functions accept one argument (a string)

def reverse_string(s: str) -> str:
    """Return the reversed string."""
    return s[::-1]

def count_vowels(s: str) -> int:
    """Count vowels in the string (a, e, i, o, u). Case-insensitive."""
    vowels = set("aeiou")
    return sum(1 for ch in s.lower() if ch in vowels)
